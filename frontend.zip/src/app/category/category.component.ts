import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute, ChildActivationEnd } from '@angular/router';
import { AuthService } from '../auth.service';
import { AngularFireAuth } from 'angularfire2/auth';
import { Observable } from 'rxjs/';
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
import { Router } from '@angular/router';
import { resolve } from '../../../node_modules/@types/q';
import { ValueTransformer } from '../../../node_modules/@angular/compiler/src/util';
@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {
  cat
  sub
  usersCustomerId
  item;
  amount;
  totalcatamt;
  transactions = [];
  date;
  constructor(private route: ActivatedRoute, public authService: AuthService,
    private afAuth: AngularFireAuth,
    private cd: ChangeDetectorRef,
    private afd: AngularFireDatabase,
    private router: Router) { }

  async ngOnInit() {
    this.transactions=[];
    this.usersCustomerId = await this.getUserDetails();
    this.sub = this.route.params.subscribe(params => {
      this.cat = params['cat'];
      console.log(this.cat);
    });
    this.getallTransactions();

  }


  async addTransaction() {
    console.log("**transaction added****");
    console.log(this.item);
    console.log('/Users/' + this.usersCustomerId + '/' + this.cat + '/');
    var json = await this.getTotal();
    var total = parseFloat(json['sum']);
   
    console.log(newtotal);
    console.log(this.date.toLocaleString());
   var exist = await this.getTransaction(this.item);
   console.log("does the transaction exist?" + exist);
  if(exist==true)
  {
    var temp = await this.deletetransaction(this.item);
    total = parseInt(temp.toString());
  }
  var newtotal = total - parseFloat(this.amount);
    this.afd.database.ref('/Users/' + this.usersCustomerId).child(this.cat).child('sum').set(newtotal);
    this.afd.database.ref('/Users/' + this.usersCustomerId + '/' + this.cat + '/').child(this.item).child('Date').set(this.date.toLocaleString());
    this.afd.database.ref('/Users/' + this.usersCustomerId + '/' + this.cat + '/').child(this.item).child('Amount').set(this.amount);

  }



  async deletetransaction(itemname)
  {
    return new  Promise( async (resolve)=>{
      var json = await this.getTotal();
      var total = parseFloat(json['sum']);
      var prevamt = await this.getTransactionamt(itemname);
      var addamt = parseFloat(prevamt.toString());
      console.log("prevamt is " + prevamt.toString());
      var newtotal = total + addamt;
      this.afd.database.ref('/Users/' + this.usersCustomerId).child(this.cat).child('sum').set(newtotal);
      this.afd.object('/Users/' + this.usersCustomerId + '/' + this.cat+'/' + itemname).remove();
      resolve(newtotal);
    })

  }

  getTotal() {
    var itemref = this.afd.list('/Users/' + this.usersCustomerId);
    //  this.categories=[];
    return new Promise((resolve) => {
      itemref.snapshotChanges().subscribe(res => {
        res.forEach(value => {
          var json = {
            'category': value.payload.key,
            'budget': value.payload.val()
          }

          if (json.category === this.cat) {
            this.totalcatamt = json.budget;
          }

        })
        resolve(this.totalcatamt);
      });
    });

  }


  getTransaction(itemname)
{
  var itemref =   this.afd.list('/Users/'+this.usersCustomerId + '/'+ this.cat);
  var tramt;
  return new Promise((resolve)=>{
    itemref.snapshotChanges().subscribe(res=> {
      this.transactions=[];
      res.forEach(value =>{
        var json = {
          'itemname':value.payload.key ,
          'amount' : value.payload.val()
        }
        console.log("object : " + json.itemname);
        console.log(itemname ==json.itemname);
        if(json.itemname==itemname)
        {
          tramt = json.amount['Amount'];
          console.log(tramt);
          resolve(true);
        }
      })
      resolve(false);
    });
    
  })

}

getTransactionamt(itemname)
{
  var itemref =   this.afd.list('/Users/'+this.usersCustomerId + '/'+ this.cat);
  var tramt;
  return new Promise((resolve)=>{
    itemref.snapshotChanges().subscribe(res=> {
      this.transactions=[];
      res.forEach(value =>{
        var json = {
          'itemname':value.payload.key ,
          'amount' : value.payload.val()
        }
        console.log("object : " + json.itemname);
        console.log(itemname ==json.itemname);
        if(json.itemname==itemname)
        {
          tramt = json.amount['Amount'];
          console.log(tramt);
          resolve(tramt);
        }
    
        
      })
    });
    
  })

}


getallTransactions(){
  
  var itemref =   this.afd.list('/Users/'+this.usersCustomerId + '/'+ this.cat);
  itemref.snapshotChanges().subscribe(res=> {
    this.transactions=[];
    res.forEach(value =>{
      var json = {
        'itemname':value.payload.key ,
        'amount' : value.payload.val()
      }
     if(json.itemname!='sum')
     {
    this.transactions.push(json);
     }
    })
  });
  
}



  getUserDetails() {
    return new Promise((resolve) => {
      this.afAuth.auth.onAuthStateChanged(user => {
        this.usersCustomerId = user.uid;
        console.log(user.uid);
        resolve(user.uid);
      });
    });
  }
}
