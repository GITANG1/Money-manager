import { Component, OnInit ,ChangeDetectorRef,Input} from '@angular/core';
import { AuthService } from '../auth.service';
import {AngularFireAuth} from 'angularfire2/auth';
import { Observable } from 'rxjs/';
import { AngularFireDatabase,AngularFireList  } from 'angularfire2/database';
import { Router } from '@angular/router';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  usersCustomerId;
  category: string;
  monthBudget : string;
  fdate: Date;
  tdate: Date;
  categories=[];
  datedTransactions=[];
  
  @Input() data: Observable<any>;

  constructor(public authService: AuthService,
    private afAuth: AngularFireAuth,
    private cd: ChangeDetectorRef,
    private afd: AngularFireDatabase,
    private router: Router) { }
 
async  ngOnInit() {
    this.usersCustomerId=await this.getUserDetails();
    var self =this;
    var itemref =   this.afd.list('/Users/'+this.usersCustomerId);
  //  this.categories=[];
    itemref.snapshotChanges().subscribe(res=> {
      res.forEach(value =>{
        var json = {
          'category':value.payload.key ,
          'budget' : value.payload.val()
        }
        console.log(json.budget['sum']);
      this.categories.push(json);
        
      })
    });
  }

  async getUid()
  {
    var Uid = await this.getUserDetails();
    return Uid;
  }

  printuser(email)
  {
    this.usersCustomerId="node";
    console.log("hello User" + email);
  }
  
  getIsloggedIn()
  {
    return this.authService.getIsloggedIn();
  }

  getUserDetails()
  {
   return new Promise((resolve)=>{
    this.afAuth.auth.onAuthStateChanged(user=>{
      this.usersCustomerId= user.uid;
      console.log(user.uid);
      resolve(user.uid);
    });
   }); 
  }

  async findtransactions()
  {
    console.log(this.fdate);
    console.log(this.tdate);
    console.log(this.tdate.valueOf()-this.fdate.valueOf());
    
   
    for(let i=0;i<this.categories.length;i++)
    {
      console.log(this.categories[i].category);
      var dates = await this.getItemsBydate(this.categories[i].category);
      console.log(dates);

    }
  }


  getItemsBydate(cat)
  {
    var itemref =   this.afd.list('/Users/'+this.usersCustomerId +'/'+cat);
    this.datedTransactions=[];
    return new Promise((resolve)=>{
    itemref.snapshotChanges().subscribe(res=> {
      res.forEach(value =>{
        var json = {
          'itemname':value.payload.key ,
          'amount' : value.payload.val()          
        }
        console.log(json.itemname);
        console.log("the date is " + json.amount['Date']);
        if(json.itemname!='sum')
        {
          let tempdate = new Date(json.amount['Date'].valueOf());
          if(tempdate.valueOf()-this.fdate.valueOf() >=0 && tempdate.valueOf()-this.tdate.valueOf() <=0 )
          {
            console.log("pushing " + json.itemname + " to the list" )
            //date.push(json)
            this.datedTransactions.push(json)
          }
       
        }
     })
    });
    resolve( this.datedTransactions);
   })
 

  }

 async createCategory()
  {
    console.log("creating Category" + this.category);
    console.log("posting to url: /Users/" + this.usersCustomerId);
    var currsum = 0;
    var transum = await this.getTotalOfTransaction(this.category);
    console.log("total of transaction is " + transum);
    currsum = parseInt(transum.toString());
    var budget  = parseInt(this.monthBudget);
    transum  = budget - currsum;
    console.log("new budget = " + budget);

    this.afd.database.ref('/Users/' + this.usersCustomerId).child(this.category).child('sum').set(transum);
    this.categories=[];
    console.log("***** " + this.categories);
  }

  signOut() {
    this.authService.logout();
  }


  getTotalOfTransaction(catname)
  {
    var itemref =   this.afd.list('/Users/'+this.usersCustomerId + '/'+ catname);
    var tramt=0;
    return new Promise((resolve)=>{
      itemref.snapshotChanges().subscribe(res=> {
      //  this.transactions=[];
        res.forEach(value =>{
          var json = {
            'itemname':value.payload.key ,
            'amount' : value.payload.val()
          }
          console.log("object : " + json.itemname);
          if(json.itemname!='sum')
          {

            tramt = tramt + parseInt((json.amount['Amount']).toString());
            console.log(json.amount['Amount']);
          }
        })
        resolve(tramt);
      });
      
    })
  
  }

  openCategory(clickedcategory)
  {
    console.log(clickedcategory);
    this.router.navigate(['category/' + clickedcategory]);
  }
}